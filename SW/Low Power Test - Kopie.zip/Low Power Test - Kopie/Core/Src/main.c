/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c2;

RTC_HandleTypeDef hrtc;

/* USER CODE BEGIN PV */

// Port Expander
static const uint8_t SX1503_ADDR = 0x20 << 1; // Use 8-bit address
static const uint8_t SX_1503_RegDataB = 0x00; // register address Pin State (0: LOW, 1: HIGH)
static const uint8_t SX_1503_RegDataA = 0x01; // register address Pin State
static const uint8_t SX_1503_RegDirB = 0x02; // register address Pin Direction (0: output, 1: Input)
static const uint8_t SX_1503_RegDirA = 0x03; // register address Pin Direction
static const uint8_t SX_1503_PullUpB = 0x04; // register address Pull Ups (0: pull up disabled, 1: pull up enabled)
static const uint8_t SX_1503_PullUpA = 0x05; // register address Pull Ups
static const uint8_t SX_1503_PullDownB = 0x06; // register address Pull Ups (0: pull up disabled, 1: pull up enabled)
static const uint8_t SX_1503_PullDownA = 0x07; // register address Pull Ups
static const uint8_t SX_1503_InterruptMaskB = 0x08; // register address Interrupt Mask (0: mask enabled, 1: mask disabled)
static const uint8_t SX_1503_InterruptMaskA = 0x09; // register address Interrupt Mask

static const uint8_t SX_1503_RegSenseHighB = 0x0A; // register address Interrupt Sense (00: none, 01: rising, 10: falling, 11: both)
static const uint8_t SX_1503_RegSenseHighA = 0x0B; // register address Interrupt Sense
static const uint8_t SX_1503_RegSenseLowB = 0x0C; // register address Interrupt Sense
static const uint8_t SX_1503_RegSenseLowA = 0x0D; // register address Interrupt Sense

static const uint8_t SX_1503_RegInterruptSourceB = 0x0E; // register address Interrupt Source (0: not the source of interrupt, 1: source of interrupt)
static const uint8_t SX_1503_RegInterruptSourceA = 0x0F; // register address Interrupt Source

static const uint8_t SX_1503_RegEventStatusB = 0x10; // register address Event status of all IOs (0: No event has occured on this IO, 1: An event has occured on this IO)
static const uint8_t SX_1503_RegEventStatusA = 0x11; // register address Event status of all IOs

// Port Expander outputs:
static const uint16_t HMI_LED_WDA = 0b0000001000000000; // Week Day Alarm LED
static const uint16_t HMI_LED_OTA = 0b0000000100000000; // One Time Alarm LED
static const uint16_t HMI_LED_TIME_DATE = 0b0000000010000000; // Time/Date LED
static const uint16_t HMI_LED_TIMER1 = 0b0000000001000000; // Timer1 LED /TODO swap back (see findings List PT1)
static const uint16_t HMI_LED_TIMER2 = 0b0000000000100000; // Timer2 LED /TODO swap back (see findings List PT1)

static const uint16_t HMI_BTN_WDA = 0b0000000000010000; // Week Day Alarm Button
static const uint16_t HMI_BTN_OTA = 0b0000000000001000; // One Time Alarm Button
static const uint16_t HMI_BTN_TIME_DATE = 0b0000000000000100; // Time/Date Button
static const uint16_t HMI_BTN_TIMER1 = 0b0000000000000010; // Timer1 Button
static const uint16_t HMI_BTN_TIMER2 = 0b0000000000000001; // Timer2 Button
static const uint16_t HMI_BTN_ENCODER = 0b0000010000000000; // Encoder Button

uint8_t HMI_BTN_WDA_state = 0x00; // latest state of Week Day Alarm Button
uint8_t HMI_BTN_OTA_state = 0x00; // latest state of One Time Alarm Button
uint8_t HMI_BTN_TIME_DATE_state = 0x00; // latest state of Time/Date Button
uint8_t HMI_BTN_TIMER1_state = 0x00; // latest state of Timer1 Button
uint8_t HMI_BTN_TIMER2_state = 0x00; // latest state of Timer2 Button
uint8_t HMI_BTN_ENCODER_state = 0x00; // latest state of Encoder Button

uint8_t HMI_BANKA_Buffer[1] = { 0x00 }; // Output Buffer of Bank A
uint8_t HMI_BANKB_Buffer[1] = { 0x00 }; // Output Buffer of Bank B


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C2_Init(void);
static void MX_RTC_Init(void);
/* USER CODE BEGIN PFP */
// setup HMI
void setup_HMI() {
	uint8_t buf[14]; // transmission buffer

	// TODO can be speed up by writing consecutive

	// Set Inputs and Outputs

	// set Bank A outputs (I/O5, I/O6, I/O7) (0: output, 1: Input)
	buf[SX_1503_RegDirA] = 0b00011111;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegDirA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set Bank B outputs (I/O8, I/O9) (0: output, 1: Input)
	buf[SX_1503_RegDirB] = 0b11111100;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegDirB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// activate Pull-up resistors for buttons

	// activate pull-ups for Bank A inputs (I/O0, I/O1, I/O2, I/O3, I/O4) (0: pull up disabled, 1: pull up enabled)
	buf[SX_1503_PullUpA] = 0b00011111;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_PullUpA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// activate pull-ups for Bank B inputs (I/10) (0: pull up disabled, 1: pull up enabled)
	buf[SX_1503_PullUpB] = 0b11111100;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_PullUpB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// deactivate pull-downs for Bank A inputs (0: pull down disabled, 1: pull downs enabled)
	buf[SX_1503_PullDownA] = 0b00000000;

	// deactivate pull-downs for Bank B inputs (0: pull down disabled, 1: pull downs enabled)
	buf[SX_1503_PullDownB] = 0b00000000;

	// activate Interrupt Mask
	uint16_t interruptMask = 0x0000; // all disabled
	interruptMask |= HMI_BTN_WDA;
	interruptMask |= HMI_BTN_OTA;
	interruptMask |= HMI_BTN_TIME_DATE;
	interruptMask |= HMI_BTN_TIMER1;
	interruptMask |= HMI_BTN_TIMER2;
	interruptMask |= HMI_BTN_ENCODER;

	// invert mask to fit register
	interruptMask = ~interruptMask;

	// set interrupt mask of Bank A
	buf[SX_1503_InterruptMaskA] = interruptMask; // lower byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_InterruptMaskA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set interrupt mask of Bank B
	buf[SX_1503_InterruptMaskB] = (interruptMask >> 8); // upper byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_InterruptMaskB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set Interrupt detection of buttons to falling edge of Bank A (00: none, 01: rising, 10: falling, 11: both)
	uint16_t SensePattern = 0x0000; // all none

	SensePattern |= 0b10; 		// I/00  falling (HMI_BTN_TIMER2)
	SensePattern |= 0b10 << 2;	// I/01  falling (HMI_BTN_TIMER1)
	SensePattern |= 0b10 << 4;	// I/02  falling (HMI_BTN_TIME_DATE)
	SensePattern |= 0b10 << 6;	// I/03  falling (HMI_BTN_OTA)
	SensePattern |= 0b10 << 8;	// I/04  falling (HMI_BTN_WDA)

	// set interrupt detection pattern of Bank A, Lower byte
	buf[SX_1503_RegSenseLowA] = SensePattern; // lower byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegSenseLowA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set interrupt detection pattern of Bank A, Upper byte
	buf[SX_1503_RegSenseHighA] = (SensePattern >> 8); // upper byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegSenseHighA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set Interrupt detection of buttons to falling edge of Bank B (00: none, 01: rising, 10: falling, 11: both)
	SensePattern = 0x0000; // all none
	SensePattern |= 0b10 << 4;	// I/010 falling (HMI_BTN_ENCODER)

	// set interrupt detection pattern of Bank B, Lower byte
	buf[SX_1503_RegSenseLowB] = SensePattern; // lower byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegSenseLowB, 1, &buf[0], 1,	HAL_MAX_DELAY);

	// set interrupt detection pattern of Bank B, Upper byte
	buf[SX_1503_RegSenseHighB] = (SensePattern >> 8); // upper byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegSenseHighB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// Send data packet, beginning with register 0x02 (SX_1503_RegDirB)
	HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegDirB, 1, &buf[SX_1503_RegDirB], 12, HAL_MAX_DELAY);
}

// set into low power config
void reset_HMI() {
	uint8_t buf[14]; // transmission buffer

	// TODO can be speed up by writing consecutive

	// Set Inputs and Outputs

	// set Bank A outputs (I/O5, I/O6, I/O7) (0: output, 1: Input)
	buf[SX_1503_RegDirA] = 0b11111111;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegDirA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set Bank B outputs (I/O8, I/O9) (0: output, 1: Input)
	buf[SX_1503_RegDirB] = 0b11111111;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegDirB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// activate Pull-up resistors for buttons

	// set pull-ups for Bank A inputs (I/O0, I/O1, I/O2, I/O3, I/O4) (0: pull up disabled, 1: pull up enabled)
	buf[SX_1503_PullUpA] = 0b00011111;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_PullUpA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set pull-ups for Bank B inputs (I/10) (0: pull up disabled, 1: pull up enabled)
	buf[SX_1503_PullUpB] = 0b00000100;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_PullUpB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set pull-downs for Bank A inputs (0: pull down disabled, 1: pull down enabled)
	buf[SX_1503_PullDownA] = 0b11100000;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_PullDownA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set pull-downs for Bank B inputs (0: pull down disabled, 1: pull down enabled)
	buf[SX_1503_PullDownB] = 0b11111011;
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_PullDownB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// activate Interrupt Mask
	uint16_t interruptMask = 0x0000; // all disabled
	interruptMask |= HMI_BTN_WDA;
	interruptMask |= HMI_BTN_OTA;
	interruptMask |= HMI_BTN_TIME_DATE;
	interruptMask |= HMI_BTN_TIMER1;
	interruptMask |= HMI_BTN_TIMER2;
	interruptMask |= HMI_BTN_ENCODER;

	// invert mask to fit register
	interruptMask = ~interruptMask;

	// set interrupt mask of Bank A
	buf[SX_1503_InterruptMaskA] = interruptMask; // lower byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_InterruptMaskA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set interrupt mask of Bank B
	buf[SX_1503_InterruptMaskB] = (interruptMask >> 8); // upper byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_InterruptMaskB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set Interrupt detection of buttons to falling edge of Bank A (00: none, 01: rising, 10: falling, 11: both)
	uint16_t SensePattern = 0x0000; // all none

	SensePattern |= 0b10; 		// I/00  falling (HMI_BTN_TIMER2)
	SensePattern |= 0b10 << 2;	// I/01  falling (HMI_BTN_TIMER1)
	SensePattern |= 0b10 << 4;	// I/02  falling (HMI_BTN_TIME_DATE)
	SensePattern |= 0b10 << 6;	// I/03  falling (HMI_BTN_OTA)
	SensePattern |= 0b10 << 8;	// I/04  falling (HMI_BTN_WDA)

	// set interrupt detection pattern of Bank A, Lower byte
	buf[SX_1503_RegSenseLowA] = SensePattern; // lower byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegSenseLowA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set interrupt detection pattern of Bank A, Upper byte
	buf[SX_1503_RegSenseHighA] = (SensePattern >> 8); // upper byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegSenseHighA, 1, &buf[0], 1, HAL_MAX_DELAY);

	// set Interrupt detection of buttons to falling edge of Bank B (00: none, 01: rising, 10: falling, 11: both)
	SensePattern = 0x0000; // all none
	SensePattern |= 0b10 << 4;	// I/010 falling (HMI_BTN_ENCODER)

	// set interrupt detection pattern of Bank B, Lower byte
	buf[SX_1503_RegSenseLowB] = SensePattern; // lower byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegSenseLowB, 1, &buf[0], 1,	HAL_MAX_DELAY);

	// set interrupt detection pattern of Bank B, Upper byte
	buf[SX_1503_RegSenseHighB] = (SensePattern >> 8); // upper byte
	//HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegSenseHighB, 1, &buf[0], 1, HAL_MAX_DELAY);

	// Send data packet, beginning with register 0x02 (SX_1503_RegDirB)
	HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegDirB, 1, &buf[SX_1503_RegDirB], 12, HAL_MAX_DELAY);
}

// set a single LED
void HMI_Write_LED_b(uint16_t LED, uint8_t state) {

	// decide if Bank A or Bank B is affected
	if (LED <= 0xFF) {
		// Bank A
		if (state == 1) {
			// set LED on
			HMI_BANKA_Buffer[0] |= LED;
		} else if (state == 0) {
			// set LED off
			HMI_BANKA_Buffer[0] &= ~LED;
		}
	} else {
		// Bank B
		if (state == 1) {
			// set LED on
			HMI_BANKB_Buffer[0] |= (LED >> 8);
		} else if (state == 0) {
			// set LED off
			HMI_BANKB_Buffer[0] &= ~(LED >> 8);
		}
	}
}

// reset all LEDs
void HMI_LED_reset_All_b() {
	// reset buffer
	HMI_BANKA_Buffer[0] = 0x00;
	HMI_BANKB_Buffer[0] = 0x00;
}

// write buffer to HMI
void HMI_Write() {
	HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegDataA, 1,
			&HMI_BANKA_Buffer[0], 1, HAL_MAX_DELAY);
	HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegDataB, 1,
			&HMI_BANKB_Buffer[0], 1, HAL_MAX_DELAY);
}


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C2_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */

  // check if some button was pressed
  uint8_t buf[2]; // receive buffer

  // read SX_1503_RegEventStatus
  HAL_I2C_Mem_Read(&hi2c2, SX1503_ADDR, SX_1503_RegEventStatusA, 1,	&buf[0], 1, HAL_MAX_DELAY);
  // read sense register Bank B
  HAL_I2C_Mem_Read(&hi2c2, SX1503_ADDR, SX_1503_RegEventStatusB, 1,	&buf[1], 1, HAL_MAX_DELAY);
  // assemble byte
  uint16_t interrupt_detection = 0x0000;
  interrupt_detection |= buf[0]; // lower byte
  interrupt_detection |= buf[1] << 8; // upper byte

  // when interrupt noted then blink LED
  if(interrupt_detection == 0x0000) {
	  // no interrupt detected:

	  // reset HMI for low power
	  reset_HMI();

	  // return to standby
	  HAL_PWR_EnterSTANDBYMode();
  }
  // interrupt detected:


  // reset flags
  buf[0] = 0xFF;
  HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegEventStatusA, 1, &buf[0], 1, HAL_MAX_DELAY);
  HAL_I2C_Mem_Write(&hi2c2, SX1503_ADDR, SX_1503_RegEventStatusB, 1, &buf[0], 1, HAL_MAX_DELAY);


  // setup LED
  setup_HMI();
  // set one led
  HMI_Write_LED_b(HMI_LED_WDA, 1);
  // write buffer to HMI
  HMI_Write();
  // wait a moment for visibility
  HAL_Delay(5);

  // deactivate all LEDs
  HMI_LED_reset_All_b();
  // write buffer to HMI
  HMI_Write();

  // reset HMI for low power
  reset_HMI();

  // enter standby
  HAL_PWR_EnterSTANDBYMode();


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	  //should never reach this point


		// test low power
		//HAL_Delay(1000);




		  /* Request to enter STANDBY mode  */
		  //HAL_PWR_EnterSTANDBYMode();



    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV16;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the peripherals clocks
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x00000000;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /** I2C Fast mode Plus enable
  */
  HAL_I2CEx_EnableFastModePlus(I2C_FASTMODEPLUS_I2C2);
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */
  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  hrtc.Init.OutPutPullUp = RTC_OUTPUT_PULLUP_NONE;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }
  /** Enable the WakeUp
  */
  if (HAL_RTCEx_SetWakeUpTimer_IT(&hrtc, 400, RTC_WAKEUPCLOCK_RTCCLK_DIV16) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Player_Pin|PWM2_Pin|PWM1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PDOK_Pin */
  GPIO_InitStruct.Pin = PDOK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(PDOK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Player_Pin PWM2_Pin PWM1_Pin */
  GPIO_InitStruct.Pin = Player_Pin|PWM2_Pin|PWM1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
